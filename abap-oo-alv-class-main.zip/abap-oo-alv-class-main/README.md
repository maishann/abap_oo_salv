# abap-oo-alv-class
SALV-Class to show any data transmitted in a table
